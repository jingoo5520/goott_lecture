package com.miniproject.persistence;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDAOImpl implements MemberDAO {

	@Autowired
	private SqlSession ses;
	
	String ns = "com.miniProject.mappers.memberMapper.";

	@Override
	public int updateUserPoint(String userId) {

		return ses.update(ns + "updateUserPoint", userId);
	}

}