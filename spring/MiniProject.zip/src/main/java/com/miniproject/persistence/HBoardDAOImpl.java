package com.miniproject.persistence;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.miniproject.domain.BoardDetailInfo;
import com.miniproject.domain.BoardUpFilesVODTO;
import com.miniproject.domain.HBoardDTO;
import com.miniproject.domain.HBoardVO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
public class HBoardDAOImpl implements HBoardDAO {

	@Inject
	private SqlSession ses;
	
	

	private static String ns = "com.miniproject.mappers.hboardMapper.";
	
	@Override
	public List<HBoardVO> selectAllBoard() throws Exception {

		
		return ses.selectList(ns + "getAllBoard");
	}
	
	@Override
	public int insertNewBoard(HBoardDTO hBoard) throws Exception {
		// TODO Auto-generated method stub
		return ses.insert(ns + "saveNewBoard", hBoard);
	}

	@Override
	public int selectMaxBoardNo() throws Exception {
		// TODO Auto-generated method stub
		// System.out.println("here" + ses.selectOne(ns + "getMaxNo"));
		return ses.selectOne(ns + "getMaxNo");
		
	}

	@Override
	public int insertBoardUpFile(BoardUpFilesVODTO file) throws Exception {
		// TODO Auto-generated method stub
		return ses.insert(ns + "saveUpFile", file);
	}

	@Override
	public HBoardVO selectBoard(int boardNo) throws Exception {
		return ses.selectOne(ns + "getBoard", boardNo);
	}

	@Override
	public List<BoardUpFilesVODTO> selectBoardUpFiles(int boardNo) throws Exception {
		return ses.selectList(ns + "getBoardUpFiles", boardNo);
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		
		HBoardDTO dao = ses.selectOne(ns + "selectResultMapTest", boardNo);
		System.out.println(dao);
		
		return dao;
	}

	@Override
	public List<BoardDetailInfo> selectBoardDetailByBoardNo(int boardNo) throws Exception {
		
		List<BoardDetailInfo> list = ses.selectList(ns + "selectBoardDetailInfoByBoardNo", boardNo);
		
		System.out.println("dao: " + list);
		
		return list;
	}

	@Override
	public int selectDateDiff(String ipAddr, int boardNo) {
		
		Map<String, Object> param = new HashMap<String, Object>();
		
		param.put("ipAddr", ipAddr);
		param.put("boardNo", boardNo);
		
		int diff = ses.selectOne(ns + "selectBoardDateDiff", param);
		
		System.out.println("selectDateDiff dao: " + diff);
		
		return diff;
	}

	@Override
	public int insertBoardReadLog(String ipAddr, int boardNo) {
		
		Map<String, Object> param = new HashMap<String, Object>();
		param.put("ipAddr", ipAddr);
		param.put("boardNo", boardNo);
		
		System.out.println("ipAddr: " + ipAddr);
		System.out.println("boardNo: " + boardNo);
		
		int result = ses.insert(ns + "saveBoardReadLog", param);
		
		System.out.println("insertBoardReadLog dao: " + result);
		return result;
	}

	@Override
	public int updateReadWhen(String ipAddr, int boardNo) {

		Map<String, Object> param = new HashMap<String, Object>();
		param.put("ipAddr", ipAddr);
		param.put("boardNo", boardNo);
		
		int result = ses.insert(ns + "updateBoardReadLog", param);
		
		System.out.println("dao: " + result);
		
		return result;
	}

	@Override
	public int updateReadCount(int boardNo) {
		int result = ses.insert(ns + "updateReadCount", boardNo);
		
		System.out.println("dao: " + result);
		
		return result;
	}

}
