package com.miniproject.persistence;

import java.util.List;

import com.miniproject.domain.BoardDetailInfo;
import com.miniproject.domain.BoardUpFilesVODTO;
import com.miniproject.domain.HBoardDTO;
import com.miniproject.domain.HBoardVO;

public interface HBoardDAO {
	List<HBoardVO> selectAllBoard() throws Exception;
	
	int insertNewBoard(HBoardDTO hBoard) throws Exception;
	
	// 최근 저장된 글의 번호를 얻어오는 메서드
	int selectMaxBoardNo() throws Exception;
	
	int insertBoardUpFile(BoardUpFilesVODTO file) throws Exception;
	
	HBoardVO selectBoard(int boardNo) throws Exception;
	
	List<BoardUpFilesVODTO> selectBoardUpFiles(int boardNo) throws Exception;
	
	// resultMap 테스트
	HBoardDTO testResultMap(int boardNo) throws Exception;
	
	// 게시글 상세 정보(게시글, 첨부파일, 유저 정보)
	List<BoardDetailInfo> selectBoardDetailByBoardNo(int boardNo) throws Exception;

	// 시간 차이 가져오기
	int selectDateDiff(String ipAddr, int boardNo);

	// 게시판 조회 기록 추가
	int insertBoardReadLog(String ipAddr, int boardNo);

	// 조회 시간 업데이트
	int updateReadWhen(String ipAddr, int boardNo);

	// 조회수 증가
	int updateReadCount(int boardNo);
}
