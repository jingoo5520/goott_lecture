package com.miniproject.service.hboard;

import java.util.List;

import javax.inject.Inject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.miniproject.domain.BoardDetailInfo;
import com.miniproject.domain.BoardUpFilesVODTO;
import com.miniproject.domain.HBoardDTO;
import com.miniproject.domain.HBoardVO;
import com.miniproject.domain.PointLogDTO;
import com.miniproject.persistence.HBoardDAO;
import com.miniproject.persistence.MemberDAO;
import com.miniproject.persistence.PointLogDAO;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service // 아래의 클래스가 서비스 객체임을 컴파일러에게 공지
public class HBoardServiceImpl implements HBoardService {

	@Autowired
	private HBoardDAO bDao;
	@Autowired
	private PointLogDAO pDao;
	@Autowired
	private MemberDAO mDao;

	// Service 단에서 해야할 작업
	// 1) Controller에서 넘겨진 파라미터 처리
	// 2) DB작업이 필요하다면 DAO단 호출
	// 3) DAO단에서 반환된 값을 Controller 단으로 넘겨줌

	@Override
	public List<HBoardVO> getAllBoard() throws Exception {

		System.out.println("HBoardServiceImpl.......");

		List<HBoardVO> list = bDao.selectAllBoard();

		return list;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public boolean saveBoard(HBoardDTO hBoard) throws Exception {
		boolean result = false;

		// 1) newBoard를 DAO단을 통해서 insert한다.
		if (bDao.insertNewBoard(hBoard) == 1) {
			
			// 첨부파일이 있다면 함께 저장
			// 1-1) 방금 저장된 게시글의 번호 가져오기
			// 1-2) 방금 저장된 게시글의 번호를 참조하는 첨부파일 정보를 insert
			
			int newBoardNo = bDao.selectMaxBoardNo();
			
			for(BoardUpFilesVODTO file : hBoard.getFileList()) {
				file.setBoardNo(newBoardNo);
				bDao.insertBoardUpFile(file);
			}
			
			
			// 2) 1)에서 insert가 성공하면, pointlog 에 저장
			if (pDao.insertPointLog(new PointLogDTO(hBoard.getWriter(), "글작성")) == 1) {
				// 3) 작성자의 userPoint값을 update한다.
				if (mDao.updateUserPoint(hBoard.getWriter()) == 1) {
					result = true;
				}
			}
		}

		return result;
	}

	@Override
//	public HBoardVO getBoard(int boardNo) throws Exception {
//		HBoardVO board = bDao.selectBoard(boardNo);
//		return board;
//	}

//	@Override
//	public List<BoardUpFilesVODTO> getBoardUpFiles(int boardNo) throws Exception {
//		// TODO Auto-generated method stub
//		return null;
//	}
	
	public HBoardDTO getBoard(int boardNo) throws Exception {
		
		HBoardDTO hboard = null;
		
		HBoardVO board = bDao.selectBoard(boardNo);
		
		List<BoardUpFilesVODTO> fileList = bDao.selectBoardUpFiles(boardNo);
		
		System.out.println("getBoard-board: " + board);
		System.out.println("getBoard-fileList: " + fileList);
		
		hboard = new HBoardDTO(boardNo, board.getTitle(), board.getContent(), board.getWriter(), fileList);
		
		return hboard;
	}

	@Override
	public HBoardDTO testResultMap(int boardNo) throws Exception {
		HBoardDTO dto = bDao.testResultMap(boardNo);
		System.out.println("service: " + dto);
		
		return dto;
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public List<BoardDetailInfo> read(int boardNo, String ipAddr) throws Exception {
		
		List<BoardDetailInfo> list = bDao.selectBoardDetailByBoardNo(boardNo);
		
		// 조회수 증가
		// boardreadlog 테이블에 ipAddr, boardNo가 동일한 행을 가져옴
		// 행이 없거나, 해당 데이터의 시간과 현재 시간을 계산해 24시간이 지났다면
		// 조회수를 1 증가시키고 시간을 현재 시간으로 업데이트 후 게시글을 가져옴
		
		int dateDiff = bDao.selectDateDiff(ipAddr, boardNo);
		
		if(dateDiff == -1) {
			// 최초 조회라면
			// 조회 정보 insert
			if(bDao.insertBoardReadLog(ipAddr, boardNo) == 1) {
				// insert 성공
				// 조회수 증가
				updateReadCount(boardNo, list);
				// 해당 글 불러오기
			} 
		} else if(dateDiff >= 1){
			// 최조 조회가 아니고, 24시간이 지난 경우
			
			// 조회 시간 업데이트
			bDao.updateReadWhen(ipAddr, boardNo);
			// 조회수 증가
			updateReadCount(boardNo, list);
			// 해당 글 불러오기
		}
		
		// 24시간이 지나지 않았다면
		// 조회수 증가 없이 게시글을 가져옴
		
		System.out.println("service: " + list);
		return list;
	}

	private void updateReadCount(int boardNo, List<BoardDetailInfo> list) {
		if(bDao.updateReadCount(boardNo) == 1) {
			for(BoardDetailInfo b : list) {
				b.setBoardNo(b.getReadCount() + 1);
			}
		}
	}
}
