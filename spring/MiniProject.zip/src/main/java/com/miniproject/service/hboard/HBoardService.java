package com.miniproject.service.hboard;

import java.util.List;

import com.miniproject.domain.BoardDetailInfo;
import com.miniproject.domain.BoardUpFilesVODTO;
import com.miniproject.domain.HBoardDTO;
import com.miniproject.domain.HBoardVO;

public interface HBoardService {
	// 게시판 전체 리스트 조회
	List<HBoardVO> getAllBoard() throws Exception;
	
	// 게시판 글 쓰기
	boolean saveBoard(HBoardDTO hBoard) throws Exception;
	
	// 게시판 상세보기
	HBoardDTO getBoard(int boardNo) throws Exception;
	
	// 게시판 업로드 파일 가져오기
	// List<BoardUpFilesVODTO> getBoardUpFiles(int boardNo) throws Exception;
	
	HBoardDTO testResultMap(int boardNo) throws Exception;
	
	// 게시글 상세 조회
	List<BoardDetailInfo> read(int boardNo, String ipAddr) throws Exception;
}
