-- member 테이블 생성
CREATE TABLE `my`.`member` (
  `userId` VARCHAR(20) NOT NULL,
  `userPwd` VARCHAR(200) NOT NULL,
  `userName` VARCHAR(12) NULL,
  `mobile` VARCHAR(13) NULL,
  `email` VARCHAR(50) NULL,
  `registerDate` DATETIME NULL DEFAULT now(),
  `userImg` VARCHAR(50) NOT NULL DEFAULT 'avatar.png',
  `userPoint` INT NULL DEFAULT 100,
  PRIMARY KEY (`userId`),
  UNIQUE INDEX `mobile_UNIQUE` (`mobile` ASC) VISIBLE,
  UNIQUE INDEX `email_UNIQUE` (`email` ASC) VISIBLE);

-- hborad 테이블 생성
CREATE TABLE `my`.`hboard` (
  `boardNo` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(20) NOT NULL,
  `content` VARCHAR(2000) NULL,
  `writer` VARCHAR(8) NULL,
  `postDate` DATETIME NULL DEFAULT now(),
  `readCount` INT NULL DEFAULT 0,
  `ref` INT NULL DEFAULT 0,
  `step` INT NULL DEFAULT 0,
  `refOrder` INT NULL DEFAULT 0,
  PRIMARY KEY (`boardNo`),
  INDEX `hboard_member_fk_idx` (`writer` ASC) VISIBLE,
  CONSTRAINT `hboard_member_fk`
    FOREIGN KEY (`writer`)
    REFERENCES `my`.`member` (`userId`)
    ON DELETE SET NULL
    ON UPDATE NO ACTION)
COMMENT = '계층형게시판';

CREATE TABLE `my`.`pointdef` (
  `pointWhy` VARCHAR(20) NOT NULL,
  `pointScore` INT NULL,
  PRIMARY KEY (`pointWhy`))
COMMENT = '유저에게 적립할 포인트에 대한 정책 정의 테이블\n어떤 사유로 몇 포인트를 지급하는지에 대해 정의';

CREATE TABLE `my`.`pointlog` (
  `pointLogNo` INT NOT NULL AUTO_INCREMENT,
  `pointWho` VARCHAR(8) NOT NULL,
  `pointWhen` DATETIME NULL DEFAULT now(),
  `pointWhy` VARCHAR(20) NOT NULL,
  `pointScore` INT NOT NULL,
  PRIMARY KEY (`pointLogNo`),
  INDEX `pointlog_member_fk_idx` (`pointWho` ASC) VISIBLE,
  CONSTRAINT `pointlog_member_fk`
    FOREIGN KEY (`pointWho`)
    REFERENCES `my`.`member` (`userId`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
COMMENT = '어떤 멤버에게 어떤 사유로 몇 포인트가 언제 지급되었는지 기록 테이블';

-- boardupfiles 테이블 생성
CREATE TABLE `boardupfiles` (
  `boardUpfileNo` int(11) NOT NULL AUTO_INCREMENT,
  `newFileName` varchar(100) NOT NULL,
  `originFileName` varchar(100) NOT NULL,
  `thumbFileName` varchar(100) DEFAULT NULL,
  `ext` varchar(20) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `boardNo` int(11) DEFAULT NULL,
  `base64Img` text,
  PRIMARY KEY (`boardUpfileNo`),
  KEY `boardupfiles_boardNo_fk_idx` (`boardNo`),
  CONSTRAINT `boardupfiles_boardNo_fk` FOREIGN KEY (`boardNo`) REFERENCES `hboard` (`boardNo`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='게시판에 업로드되는 파일을 기록하는 테이블';


-- 회원가입
insert into member(userId, userPwd, userName, mobile, email) 
values("kildong", sha1(md5("1234")) ,"홍길동", "010-1111-1111", "kildong123@abc.com" );
insert into member(userId, userPwd, userName, mobile, email) 
values("kilsun", sha1(md5("1234")) ,"홍길순", "010-2222-2222", "kilsun123@abc.com" );

-- 게시글 등록
insert into hboard(title, content, writer)
values("첫 번째 게시글", "내용1", "kildong");

insert into hboard(title, content, writer)
values("두 번째 게시글", "내용2", "kilsun");

use my;
select * from member;
select * from hboard;

commit;

-- 포인트 획득 로그
INSERT INTO `my`.`pointdef` (`pointWhy`, `pointScore`) VALUES ('회원가입', '100');
INSERT INTO `my`.`pointdef` (`pointWhy`, `pointScore`) VALUES ('로그인', '1');
INSERT INTO `my`.`pointdef` (`pointWhy`, `pointScore`) VALUES ('글작성', '10');
INSERT INTO `my`.`pointdef` (`pointWhy`, `pointScore`) VALUES ('댓글작성', '2');


-- 게시글에 첨부한 파일정보를 저장
-- 번호 가져오기
select max(boardNo) from hboard;

-- 업로드된 첨부파일을 저장하는 쿼리문
-- insert into boardupfiles(newFileName, originFileName, thumbFileName, ext, size, boardNo, base64Img) 
-- values(#{newFileName}, #{originFileName}, #{thumbFileName}, #{ext}, #{size}, #{boardNo}, #{base64Img});

-- 게시글 번호로 조회
select * from hboard where boardNo = 33;

-- 업로드 파일 조회
select * from boardupfiles where boardNo = 39;

select boardNo, title, content, writer from hboard where boardNo = 39;

-- 게시글 상세페이지
-- boardNo 번째 글의 hboard 모든 컬럼과, 해당 글의 모든 업로드 파일과, 작성자의 이름과 이메일을 가져오기 위한 쿼리문 작성

select h.*, f.*, m.userId, m.email
from hboard h left outer join boardupfiles f on h.boardNo = f.boardNo
join member m on h.writer = m.userId
where h.boardNo = 39;

SHOW CREATE TABLE boardreadlog;

-- boardreadlong 테이블 생성
CREATE TABLE `boardreadlog` (
  `boardReadLogNo` int NOT NULL AUTO_INCREMENT,
  `readWho` varchar(130) NOT NULL,
  `readWhen` datetime DEFAULT CURRENT_TIMESTAMP,
  `boardNo` int DEFAULT NULL,
  PRIMARY KEY (`boardReadLogNo`),
  CONSTRAINT `boardreadlog_boardno_fk` 
  FOREIGN KEY (`boardReadLogNo`) REFERENCES `hboard` (`boardNo`)) 
  ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci 
  COMMENT='조회수 처리를 위한 클라이언트 ip와 게시글을 읽은 시간, 게시글 번호를 저장하기 위한 테이블';

select * from boardreadlog;

insert into boardreadlog(readWho, boardNo) values('127:0:0:1', 39);

select datediff(now(), readWhen) 
from boardreadlog 
where readWho = '127:0:0:1' and boardNo = 39;

-- 1) ipAddr 유저가 n번 글을 언제 조회했는지
select readWhen
from boardreadlog 
where readWho = '127:0:0:1' and boardNo = 39;

-- 2) 1번의 결과가 null이면 insert
insert into boardreadlog(readwho, boardNo) values(?, ?);

-- 3) 1번의 결과가 null이 아니면 현재 시간과 이전에 읽은 날짜시간의 차이를 구해야함
-- null인 경우에는 -1 출력
select ifnull(datediff(now(), (select readWhen from boardreadlog where readWho = '127:0:0:1' and boardNo = 39)) , -1) as diff;


--  조회수 증가(update)
-- update hboard set readCount = readCount + 1 where boardNo = #{boardNo};

-- 조회 시간 업데이트(조회 시간에서 24시간 경과 후에만)
-- update boardreadlog set readWhen = now() 
-- where readWho = #{readWho} and boardNo = #{boardNo};

delete from boardreadlog;
delete from hboard;
delete from boardupfiles;

select * from hboard;
select * from boardreadlog;
select * from boardupfiles;

rollback;


select ifnull(datediff(now(), (select readWhen from boardreadlog where readWho = '127:0:0:1' and boardNo = 46)) , -1) as datediff;

insert into boardreadlog(readWho, boardNo) values('127:0:0:1', 46);

drop table hboard;
drop table boardupfiles;
drop table boardreadlog;
