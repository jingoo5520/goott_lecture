package webjingoo.tightcoupling;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Remote remocon = new Remote();
		
		remocon.turnOnTv();
		
	}

}
