package webjingoo;

public interface Phone {
	// public abstract 생략가능
	public abstract void phoneCall();
	void answerPhone();
}
