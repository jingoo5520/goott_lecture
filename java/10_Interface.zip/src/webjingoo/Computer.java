package webjingoo;

public interface Computer {
	
}
