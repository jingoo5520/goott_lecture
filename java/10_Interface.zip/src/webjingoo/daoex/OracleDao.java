package webjingoo.daoex;

public class OracleDao implements DataAccessObject {

	@Override
	public void select() {
		// TODO Auto-generated method stub
		System.out.println("Oracle 데이터조회");
	}

	@Override
	public void insert() {
		// TODO Auto-generated method stub
		System.out.println("Oracle 데이터추가");
	}

	@Override
	public void update() {
		// TODO Auto-generated method stub
		System.out.println("Oracle 데이터수정");
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		System.out.println("Oracle 데이터삭제");
	}

}
