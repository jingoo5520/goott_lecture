package webjingoo;

public interface Camera {
	void takePicture();
}
