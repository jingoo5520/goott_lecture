package webjingoo;

public class MobilePhone implements Phone, Camera{

	@Override
	public void phoneCall() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void answerPhone() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void takePicture() {
		// TODO Auto-generated method stub
		
	}
	
}
