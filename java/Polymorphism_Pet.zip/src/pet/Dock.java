package pet;

public class Dock {

}
